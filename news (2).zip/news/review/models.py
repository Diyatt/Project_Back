from django.db import models


class Sport(models.Model):
    """A company that publishes books."""
    title = models.CharField(max_length=50,
                            help_text="The name of the Publisher.")

    def __str__(self):
        return self.name


class SDU(models.Model):
    """A company that publishes books."""
    title = models.CharField(max_length=50,
                             help_text="The name of the Publisher.")

    def __str__(self):
        return self.name


class Economy(models.Model):
    """A company that publishes books."""
    title = models.CharField(max_length=50,
                             help_text="The name of the Publisher.")

    def __str__(self):
        return self.name


class Social(models.Model):
    """A company that publishes books."""
    title = models.CharField(max_length=50,
                             help_text="The name of the Publisher.")

    def __str__(self):
        return self.name